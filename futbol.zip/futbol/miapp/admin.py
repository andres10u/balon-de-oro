
from django.contrib import admin
from django import forms
from .models import Jugador, Premio, Ganador


@admin.register(Jugador)
class JugadorAdmin(admin.ModelAdmin):
    list_display = (
        "nombre",
        "pais",
        "equipo",
        "posicion",
        "numero_dorsal",
    )
    search_fields = ("nombre", "equipo", "pais")


@admin.register(Premio)
class PremioAdmin(admin.ModelAdmin):
    list_display = ("nombre", "anio")
    search_fields = ("nombre",)
    list_filter = ("anio",)

    def get_form(self, request, obj=None, **kwargs):
        form = super().get_form(request, obj, **kwargs)
        form.base_fields["anio"].widget = forms.TextInput(
            attrs={"placeholder": "Ejemplo: 2000"}
        )
        return form


@admin.register(Ganador)
class GanadorAdmin(admin.ModelAdmin):
    list_display = (
        "jugador",
        "premio",
        "fecha_entrega",
        "votos",
    )
    list_filter = ("premio", "fecha_entrega")
    search_fields = ("jugador__nombre", "premio__nombre")
    list_editable = ("votos",)
