
from django import forms
from .models import Jugador, Premio, Ganador


class FormsJugador(forms.ModelForm):
    class Meta:
        model = Jugador
        fields = [
            'nombre',
            'pais',
            'equipo',
            'posicion',
            'descripcion',
            'numero_dorsal'
        ]
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'pais': forms.TextInput(attrs={'class': 'form-control'}),
            'equipo': forms.TextInput(attrs={'class': 'form-control'}),
            'posicion': forms.TextInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control'}),
            'numero_dorsal': forms.NumberInput(attrs={'class': 'form-control'}),
        }


class FormsPremio(forms.ModelForm):
    class Meta:
        model = Premio
        fields = [
            'nombre',
            'anio',
            'descripcion'
        ]
        widgets = {
            'nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'anio': forms.NumberInput(attrs={'class': 'form-control'}),
            'descripcion': forms.Textarea(attrs={'class': 'form-control'}),
        }


class FormsGanador(forms.ModelForm):
    class Meta:
        model = Ganador
        fields = [
            'jugador',
            'premio',
            'fecha_entrega',
            'votos'
        ]
        widgets = {
            'jugador': forms.Select(attrs={'class': 'form-control'}),
            'premio': forms.Select(attrs={'class': 'form-control'}),
            'fecha_entrega': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'votos': forms.NumberInput(attrs={'class': 'form-control'}),
        }
