
from django.db import models


class Jugador(models.Model):
    nombre = models.CharField(max_length=100)
    pais = models.CharField(max_length=60)
    equipo = models.CharField(max_length=100)
    posicion = models.CharField(max_length=50)
    descripcion = models.TextField()
    numero_dorsal = models.IntegerField()

    def __str__(self):
        return self.nombre


class Premio(models.Model):
    nombre = models.CharField(max_length=100)
    anio = models.IntegerField()
    descripcion = models.TextField()

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['nombre', 'anio'],
                name='premio_unico_por_anio'
            )
        ]

    def __str__(self):
        return f"{self.nombre} - {self.anio}"


class Ganador(models.Model):
    jugador = models.ForeignKey(
        Jugador,
        on_delete=models.CASCADE,
        related_name="premios_ganados"
    )
    premio = models.OneToOneField(
        Premio,
        on_delete=models.CASCADE,
        related_name="ganador"
    )
    fecha_entrega = models.DateField()
    votos = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.jugador.nombre} - {self.premio.nombre}"
