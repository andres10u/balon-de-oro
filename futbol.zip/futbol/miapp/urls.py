
from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("agregar/", views.agregar_ganador, name="agregar_ganador"),
    path("editar/<int:id>/", views.agregar_ganador, name="editar_ganador"),
    path("eliminar/<int:id>/", views.eliminar_ganador, name="eliminar_ganador"),
]
