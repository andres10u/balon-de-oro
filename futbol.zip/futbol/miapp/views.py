
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Ganador
from .forms import FormsGanador


def index(request):
    ganadores = Ganador.objects.select_related(
        "jugador", "premio"
    ).order_by("-premio__anio", "-votos")

    return render(request, "miapp/index.html", {
        "ganadores": ganadores,
    })


def agregar_ganador(request, id=None):
    ganador = None

    if id is not None:
        ganador = get_object_or_404(Ganador, pk=id)

    if request.method == "POST":
        form = FormsGanador(request.POST, instance=ganador)

        if form.is_valid():
            form.save()

            if ganador:
                messages.success(
                    request, "Ganador actualizado correctamente."
                )
            else:
                messages.success(
                    request, "Ganador agregado correctamente."
                )

            return redirect("agregar_ganador")
    else:
        form = FormsGanador(instance=ganador)

    ganadores = Ganador.objects.select_related(
        "jugador", "premio"
    ).order_by("-premio__anio", "-votos")

    return render(request, "miapp/agregar_ganador.html", {
        "form": form,
        "ganadores": ganadores,
        "ganador": ganador,
    })


def eliminar_ganador(request, id):
    ganador = get_object_or_404(Ganador, pk=id)

    if request.method == "POST":
        nombre = ganador.jugador.nombre
        ganador.delete()

        messages.success(
            request,
            f'El ganador "{nombre}" ha sido eliminado.'
        )

        return redirect("agregar_ganador")

    return render(request, "miapp/confirmar_eliminar.html", {
        "ganador": ganador,
    })
